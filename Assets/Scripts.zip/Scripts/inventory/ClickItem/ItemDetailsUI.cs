﻿//sử dụng hero phải khai báo
using Assets.HeroEditor.Common.CharacterScripts;
using HeroEditor.Common.Enums;
using Newtonsoft.Json;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using Unity.VisualScripting;
using Unity.VisualScripting.Antlr3.Runtime.Misc;
using UnityEngine;
using UnityEngine.UI;


public class ItemDetailsUI : MonoBehaviour
{
    public string armorId = "Extensions.Legendary.Armor.AizenHeavyArmor";
    public string armorId1 = "Extensions.AbandonedWorkshop.Armor.ArcaneRobe";
    public string bowId = "Extensions.Legendary.Bow.BowOfCompassion";
    public GameObject playerClone; // Clone preview trong scene

    public static ItemDetailsUI Instance;

    public GameObject panel;
    public Image icon;
    public TextMeshProUGUI nameText;
    public TextMeshProUGUI descText;
    public Button useButton;
    public Button dropButton;
    public Button closeButton;
    //sử dụng thông qua character ( sử dụng đồ )
    public Character character; // Gán trong Inspector

    private InventoryItem1 currentItem;
    private void Start()
    {

        StartCoroutine(EquipArmorFromSavedJson());
        if (character == null && CharacterUIManager1.Instance != null)
        {
            character = CharacterUIManager1.Instance.character;
            Debug.Log(" character được gán từ CharacterUIManager1.");
        }
    }
    void Awake()
    {
        Debug.Log("Da chay awake ItemDetailsUI");
        Instance = this;
        panel.SetActive(false);
    }
    public void Show(InventoryItem1 item)
    {
        currentItem = item;
        Debug.Log($"🟢 Show panel: {item.itemId} / {item.quantity}");

        icon.sprite = item.stats?.Icon;
        nameText.text = item.stats?.Name ?? "Không rõ";
        descText.text = $"ID: {item.itemId}\nSố lượng: {item.quantity}";

        if (item.stats != null)
        {
            descText.text = $"<b>{item.stats.Description}</b>\n" +
                            //$"<b>Số lượng:</b> {item.quantity}\n\n" +
                            $"<b>Chỉ số:</b>\n" +
                            $"• Sức mạnh: {item.stats.Strength}\n" +
                            $"• Phòng thủ: {item.stats.Defense}\n" +
                            $"• Nhanh nhẹn: {item.stats.Agility}\n" +
                            $"• Trí tuệ: {item.stats.Intelligence}\n" +
                            $"• Sinh lực: {item.stats.Vitality}";
        }
        else
        {
            descText.text = $"ID: {item.itemId}\nSố lượng: {item.quantity}\n(stats null)";
        }

        panel.SetActive(true);
    }

    public void UseItem()
    {
        EquipToCharacter(currentItem.stats);
        

        if (CharacterUIManager1.Instance != null && currentItem != null)
        {
            string type = currentItem.stats.Type;
            string itemId = currentItem.itemId;

            // Nếu là Gloves thì hiển thị lại đúng slot từ ArmorSlots
            if (type == "Gloves")
            {
                CharacterUIManager1.Instance.DisplayItem(
                    CharacterUIManager1.Instance.ArmorSlots[2], // Index 2 là Gloves
                    itemId,
                    "Gloves"
                );

            }
            if (type == "Belt")
            {
                CharacterUIManager1.Instance.DisplayItem(
                    CharacterUIManager1.Instance.ArmorSlots[5], // Index 2 là Gloves
                    itemId,
                    "Belt"

                );

            }
            if (type == "Boots")
            {
                CharacterUIManager1.Instance.DisplayItem(
                    CharacterUIManager1.Instance.ArmorSlots[1], // Index 2 là Gloves
                    itemId,
                    "Boots"
                );

            }
            if (type == "Armor")
            {
                CharacterUIManager1.Instance.DisplayItem(
                    CharacterUIManager1.Instance.ArmorSlots[0], // Index 2 là Gloves
                    itemId,
                    "Armor"
                );
                CharacterEquipHandler.TestEquipArmor(character, currentItem.itemId);

            }
            if (type == "Helmet")
            {
                CharacterUIManager1.Instance.DisplayItem1(
                    CharacterUIManager1.Instance.Helmetslot, // Index 2 là Gloves
                    itemId,
                    "Helmet"
                );

            }

            if (type == "MeleeWeapon1H")
            {
                CharacterUIManager1.Instance.DisplayItem1(
                    CharacterUIManager1.Instance.MeleeWeapon1Hslot, // Index 2 là Gloves
                    itemId,
                    "MeleeWeapon1H"
                );
            }
            if (type == "MeleeWeapon2H")
            {
                CharacterUIManager1.Instance.DisplayItem1(
                    CharacterUIManager1.Instance.MeleeWeapon2Hslot, // Index 2 là Gloves
                    itemId,
                    "MeleeWeapon2H"
                );
            }
            if (type == "Cape")
            {
                CharacterUIManager1.Instance.DisplayItem1(
                    CharacterUIManager1.Instance.Capeslot, // Index 2 là Gloves
                    itemId,
                    "Cape"
                );
            }
            if (type == "Shield")
            {
                CharacterUIManager1.Instance.DisplayItem1(
                    CharacterUIManager1.Instance.Shieldslot, // Index 2 là Gloves
                    itemId,
                    "Shield"
                );
            }
            if (type == "Pauldrons")
            {
                CharacterUIManager1.Instance.DisplayItem1(
                    CharacterUIManager1.Instance.ArmorSlots[3], // Index 2 là Gloves
                    itemId,
                    "Pauldrons"
                );
            }
            if (type == "Glasses")
            {
                CharacterUIManager1.Instance.DisplayItem1(
                    CharacterUIManager1.Instance.Glassesslot, // Index 2 là Gloves
                    itemId,
                    "Glasses"
                );
            }
            if (type == "Vest")
            {
                CharacterUIManager1.Instance.DisplayItem1(
                    CharacterUIManager1.Instance.ArmorSlots[4], // Index 2 là Gloves
                    itemId,
                    "Vest"
                );
            }
            if (type == "Hair")
            {
                CharacterUIManager1.Instance.DisplayItem1(
                    CharacterUIManager1.Instance.Hairslot, // Index 2 là Gloves
                    itemId,
                    "Hair"
                );
            }
            if (type == "Back")
            {
                CharacterUIManager1.Instance.DisplayItem1(
                    CharacterUIManager1.Instance.Backslot, // Index 2 là Gloves
                    itemId,
                    "Back"
                );
            }
            if (type == "Bow")
            {
                CharacterUIManager1.Instance.DisplayItem1(
                    CharacterUIManager1.Instance.Bowslot, // Index 2 là Gloves
                    itemId,
                    "Bow"
                );
            }
            CharacterEquipHandler.TestEquipBow(character, currentItem.itemId);



            // Có thể làm tương tự với Boots, Vest, Belt, Armor, Pauldrons...
        }

        if (currentItem == null || currentItem.stats == null)
        {
            Debug.LogError(" currentItem null hoặc thiếu stats.");
            return;
        }

        if (string.IsNullOrEmpty(PlayerDataHolder1.CharacterJson))
        {
            Debug.LogError(" Chưa có CharacterJson.");
            return;
        }

        // Parse JSON hiện tại từ nhân vật
        var dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(PlayerDataHolder1.CharacterJson);

        //  Xoá vũ khí cũ nếu đang chuyển đổi loại
        if (currentItem.stats.Type == "Bow")
        {
            dict.Remove("PrimaryMeleeWeapon");
            dict.Remove("SecondaryMeleeWeapon");
        }
        if (currentItem.stats.Type == "PrimaryMeleeWeapon" || currentItem.stats.Type == "MeleeWeapon1H")
        {
            dict.Remove("Bow");
            dict.Remove("SecondaryMeleeWeapon");
        }
        if (currentItem.stats.Type == "SecondaryMeleeWeapon" || currentItem.stats.Type == "MeleeWeapon2H")
        {
            dict.Remove("PrimaryMeleeWeapon");
            dict.Remove("Bow");
        }


        // Ghi đè item vào đúng slot
        switch (currentItem.stats.Type)
        {
            case "Helmet":
            case "Armor":
            case "Boots":
            case "Gloves":
            case "Pauldrons":
            case "Vest":
            case "Belt":
            case "Shield":
            case "Cape":
            case "Back":
            case "Glasses":
            case "Hair":

                //case "Bow":
                dict[currentItem.stats.Type] = currentItem.itemId;
                break;
            case "Bow":
                dict["Bow"] = currentItem.itemId;
                dict["WeaponType"] = "Bow";

                break;
            case "MeleeWeapon1H":
                dict["PrimaryMeleeWeapon"] = currentItem.itemId;
                dict["WeaponType"] = "Melee1H";

                break;
            case "MeleeWeapon2H":
                dict["SecondaryMeleeWeapon"] = currentItem.itemId;
                dict["WeaponType"] = "Melee2H";

                break;
            default:
                Debug.LogWarning($"❌ Loại chưa hỗ trợ: {currentItem.stats.Type}");
                return;
        }
        // Serialize lại JSON
        // Serialize lại JSON
        string updatedJson = JsonConvert.SerializeObject(dict, Formatting.None);
        PlayerDataHolder1.CharacterJson = updatedJson;

        if (PlayerAvatar.Instance != null && PlayerAvatar.Instance.HasStateAuthority)
        {
            PlayerAvatar.Instance.UpdateCharacterJson(updatedJson);
            PlayerAvatar.Instance.SendCharacterJsonToAllClients(); //  thêm dòng này!
            Debug.Log("Đã gửi JSON mới cho tất cả client.");
        }

        //}
        // 🟡 Nếu đang test trên clone, gửi JSON về player thật thông qua controller
        if (playerClone != null)
        {
            var cloneCtrl = playerClone.GetComponent<PlayerCloneController>();
            if (cloneCtrl != null)
            {
                cloneCtrl.SendCharacterJsonToTarget(updatedJson); //  Gửi từ clone → player thật
            }
            else
            {
                Debug.LogError("❌ Không tìm thấy PlayerCloneController.");
            }
        }
        else
        {
            Debug.LogWarning("⚠️ playerClone chưa được gán.");
        }

        // 🟠 Đồng bộ với UI trung tâm (chỉ hiển thị preview)
        if (CharacterUIManager1.Instance != null)
        {
            string type = currentItem.stats.Type;
            if (type == "Armor")
            {
                CleanUnsupportedEntries(dict, character);
                CharacterUIManager1.Instance.character.FromJson(updatedJson);
                StartCoroutine(EquipArmorNextFrame(currentItem.itemId));
            }
            else if (CharacterEquipHandler.ArmorTypeToIndexes.ContainsKey(type))
            {
                CharacterEquipHandler.EquipPartialArmor(character, type, currentItem.stats.Icon);

            }
            else
            {
                CharacterUIManager1.Instance.character.FromJson(updatedJson);
            }
        }

        //  Tắt panel
        Debug.Log("Đã dùng item, cập nhật và gửi JSON về player thật.");
        panel.SetActive(false);
        // Gửi JSON lên server để lưu theo account của chính client
        // Thay vì check HasStateAuthority của PlayerAvatar.Instance, check theo account hiện tại
        if (AuthManager.Instance != null)
        {
            Debug.Log("🟢 Gửi JSON lên server để lưu theo account của client hiện tại.");
            AuthManager.Instance.StartCoroutine(AuthManager.Instance.SaveCharacterToServer(updatedJson));
        }
        else
        {
            Debug.LogError("❌ Không tìm thấy AuthManager.");
        }



    }

    public IEnumerator EquipArmorNextFrame(string itemId)
    {

        yield return null; // Đợi 1 frame để SpriteCollection sẵn sàng

        CharacterEquipHandler.TestEquipArmor(character, itemId);
    }





    public void DropItem()
    {
        Debug.Log($"Đã vứt {currentItem.itemName}");
        panel.SetActive(false);
        // Gọi xử lý vứt item tại đây
    }

    public void Close()
    {
        panel.SetActive(false);
    }
    private void EquipToCharacter(ItemStats stats)
    {
        Debug.Log(" ĐANG EQUIP: stats.Type = " + stats.Type + ", stats.Icon = " + (stats.Icon != null ? stats.Icon.name : "NULL"));
        string spriteName = ExtractSpriteName(stats.itemId); // Lấy từ itemId
        Sprite sprite = null;
        switch (stats.Type)
        {
            case "Helmet":
                character.Helmet = stats.Icon;
                break;
            case "Glasses":
                character.Glasses = stats.Icon;
                break;
            case "Cape":
                character.Cape = stats.Icon;
                break;
            case "Back":
                character.Back = stats.Icon;
                break;
            case "Hair":
                character.Hair = stats.Icon;
                break;
            case "Shield":
                character.Shield = stats.Icon;
                break;
            case "Armor":
                EnsureArmorListSize(0);
                character.Armor[0] = stats.Icon;
                break;
            case "Boots":
                EnsureArmorListSize(1);
                character.Armor[1] = stats.Icon;
                break;
            case "Gloves":
                EnsureArmorListSize(2);
                character.Armor[2] = stats.Icon;
                break;
            case "Pauldrons":
                EnsureArmorListSize(3);
                character.Armor[3] = stats.Icon;
                break;
            case "Vest":
                EnsureArmorListSize(4);
                character.Armor[4] = stats.Icon;
                break;
            case "Belt":
                EnsureArmorListSize(5);
                character.Armor[5] = stats.Icon;
                break;
            // === Vũ khí ===
            case "PrimaryMeleeWeapon":
            case "MeleeWeapon1H":
                sprite = FindSpriteInCollection(spriteName, character.SpriteCollection.MeleeWeapon1H)
                         ?? stats.Icon;
                character.PrimaryMeleeWeapon = sprite;
                character.WeaponType = WeaponType.Melee1H;
                break;

            // ===== Secondary Melee (Paired / 2H) =====
            case "MeleeWeapon2H":
            case "SecondaryMeleeWeapon":
                {
                    var entry = character.SpriteCollection.MeleeWeapon2H
                        .FirstOrDefault(e => e.Id == stats.itemId);

                    if (entry == null)
                    {
                        Debug.LogError($"❌ Không tìm thấy MeleeWeapon2H entry: {stats.itemId}");
                        return;
                    }

                    character.WeaponType = WeaponType.Melee2H;
                    character.Equip(entry, EquipmentPart.MeleeWeapon2H);
                    break;
                }

            case "Bow":
                {
                    var entry = character.SpriteCollection.Bow
                        .FirstOrDefault(e => e.Id == stats.itemId);

                    if (entry == null || entry.Sprites.Count < 2)
                    {
                        Debug.LogError($" Không tìm thấy Bow entry hoặc thiếu sprite: {stats.itemId}");
                        return;
                    }

                    character.WeaponType = WeaponType.Bow;
                    character.Equip(entry, EquipmentPart.Bow);
                    break;
                }
            default:
                Debug.LogWarning($" Không hỗ trợ loại trang bị: {stats.Type}");
                break;
        }

    }

    private void EnsureArmorListSize(int index)
    {
        while (character.Armor.Count <= index)
        {
            character.Armor.Add(null);
        }
    }
    private string ExtractSpriteName(string itemId)
    {
        if (string.IsNullOrEmpty(itemId)) return "";
        int lastDot = itemId.LastIndexOf('.');
        return lastDot >= 0 ? itemId.Substring(lastDot + 1) : itemId;
    }

    private Sprite FindSpriteInCollection(string spriteName, List<HeroEditor.Common.SpriteGroupEntry> groupEntries)
    {
        foreach (var entry in groupEntries)
        {
            if (entry.Sprites == null) continue;
            foreach (var sprite in entry.Sprites)
            {
                if (sprite != null && sprite.name == spriteName)
                    return sprite;
            }
        }

        Debug.LogError($" Không tìm thấy sprite có tên: {spriteName}");
        return null;
    }
    private void CleanUnsupportedEntries(Dictionary<string, string> dict, Character character)
    {
        void RemoveIfMissing(string key, List<HeroEditor.Common.SpriteGroupEntry> group)
        {
            if (dict.ContainsKey(key) && !group.Any(e => e.Id == dict[key]))
            {
                Debug.LogWarning($" Xoá '{key}' vì không tìm thấy: {dict[key]}");
                dict.Remove(key);
            }
        }

        RemoveIfMissing("PrimaryMeleeWeapon", character.SpriteCollection.MeleeWeapon1H);
        RemoveIfMissing("SecondaryMeleeWeapon", character.SpriteCollection.MeleeWeapon2H);
        RemoveIfMissing("Bow", character.SpriteCollection.Bow);
        RemoveIfMissing("Helmet", character.SpriteCollection.Helmet);
        RemoveIfMissing("Cape", character.SpriteCollection.Cape);
        RemoveIfMissing("Back", character.SpriteCollection.Back);
        RemoveIfMissing("Shield", character.SpriteCollection.Shield);
        // Có thể thêm các loại khác nếu bạn sử dụng.
    }
    private IEnumerator EquipArmorFromSavedJson()
    {
        yield return null; // đợi 1 frame để sprite collection sẵn sàng

        var json = PlayerDataHolder1.CharacterJson;
        if (string.IsNullOrEmpty(json)) yield break;

        var dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
        if (dict.TryGetValue("Armor", out var armorId))
        {
            CharacterEquipHandler.TestEquipArmor(character, armorId);
        }
        if (dict.TryGetValue("WeaponType", out var type) && type == "Melee2H")
        {
            if (dict.TryGetValue("SecondaryMeleeWeapon", out var weaponId))
            {
                var entry = character.SpriteCollection.MeleeWeapon2H.FirstOrDefault(e => e.Id == weaponId);
                if (entry != null)
                {
                    character.WeaponType = WeaponType.Melee2H;
                    character.Equip(entry, EquipmentPart.MeleeWeapon2H);
                }
            }
        }
    }
}