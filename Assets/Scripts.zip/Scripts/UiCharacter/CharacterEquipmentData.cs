﻿/*using System.Collections.Generic;

[System.Serializable]
public class CharacterEquipmentData
{
    public string Head;
    public string Body;
    public string Ears;
    public string Hair;
    public string Beard;
    public string Helmet;
    public string Glasses;
    public string Mask;
    public string Cape;
    public string Back;
    public string Shield;
    public string WeaponType;
    public string Expression;
    public string HideEars;
    public string FullHair;
    public string BodyScaleX;
    public string BodyScaleY;
    public string PrimaryMeleeWeapon;
    public string SecondaryMeleeWeapon;

    // Armor: từ Armor[0] đến Armor[25]
    public List<string> Armor = new();

    // Expression (chỉ lấy Default để demo)
    public string Expression_Default_Eyebrows;
    public string Expression_Default_Eyes;
    public string Expression_Default_EyesColor;
    public string Expression_Default_Mouth;
}
*/