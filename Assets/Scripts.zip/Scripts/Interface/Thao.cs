/*using UnityEngine;

public class Thao : ItemDetailsUI 
{
    public void zzzzdo()
    {
        UnequipItem();
    }
}
*/