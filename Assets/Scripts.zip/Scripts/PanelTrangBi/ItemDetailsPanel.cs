﻿using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
// hiển thị bảng panel thông tin trang bị nhân vật
public class ItemDetailsPanel : MonoBehaviour
{
    public static ItemDetailsPanel Instance;

    public GameObject panel;
    public Image icon;
    public TMP_Text description;
    public TMP_Text Type;
    public TMP_Text Name;
    public Button unequipButton; // Gán trong Inspector
    private string currentItemId;
    private string currentType;

    private void Awake()
    {
        Instance = this;
        panel.SetActive(false);
    }

    public void Show(string id, Sprite iconSprite, string type = null)
    {
        panel.SetActive(true);
        icon.sprite = iconSprite;

        currentItemId = id;
        currentType = type;

        string name = id.Split('.').Length > 0 ? id.Split('.').Last() : id;
        string displayType = type ?? "Không rõ loại";

        description.text = $"{displayType}\n\n{GetStatsFromId(id)}";
        Type.text = $"Loại: {displayType}";

        Name.text = $"Tên: {name}";
    }


    public void Hide()
    {
        panel.SetActive(false);
    }

    private string GetStatsFromId(string id)
    {
        var stats = ItemStatDatabase.Instance.GetStats(id);
        if (stats == null)
            return "Không có thông tin.";

        return
            $"Sức mạnh: {stats.Strength}\n" +
            $"Phòng thủ: {stats.Defense}\n" +
            $"Nhanh nhẹn: {stats.Agility}\n" +
            $"Trí tuệ: {stats.Intelligence}\n" +
            $"Thể lực: {stats.Vitality}";
    }
    //gỡ ttrang bị 
    public void OnUnequipButtonClick()
    {
        if (string.IsNullOrEmpty(currentType))
        {
            return;
        }

        if (!System.Enum.TryParse(currentType, out HeroEditor.Common.Enums.EquipmentPart part))
        {
            return;
        }

        var character = CharacterUIManager1.Instance?.character;

        if (character == null)
        {
            return;
        }

        // Gỡ trên clone
        character.UnEquip(part);

        // Xoá khỏi JSON
        var json = PlayerDataHolder1.CharacterJson;
        if (!string.IsNullOrEmpty(json))
        {
            var dict = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, string>>(json);

            dict[currentType] = "";

            if (currentType == "Bow" || currentType.Contains("MeleeWeapon"))
            {
                dict["WeaponType"] = "";
            }

            string updatedJson = Newtonsoft.Json.JsonConvert.SerializeObject(dict);
            PlayerDataHolder1.CharacterJson = updatedJson;

            // 🟢 Gửi về player thật thông qua playerClone
            var playerClone = ItemDetailsUI.Instance?.playerClone;
            if (playerClone != null)
            {
                var cloneCtrl = playerClone.GetComponent<PlayerCloneController>();
                if (cloneCtrl != null)
                {
                    cloneCtrl.SendCharacterJsonToTarget(updatedJson); // ✅ gửi clone → player thật
                }
            }

            // 🟠 Đồng bộ lên UI preview
            CharacterUIManager1.Instance?.character.FromJson(updatedJson);

            // 🔵 Gửi lên server để lưu
            if (AuthManager.Instance != null)
            {
                AuthManager.Instance.StartCoroutine(AuthManager.Instance.SaveCharacterToServer(updatedJson));
            }
        }

        Hide();
    }




}