﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class ShopPKUIManager : BaseShopUIManager
{
    protected override ShopType CurrentShopType => ShopType.Consumable;
    protected override List<NpcShopItem> FilterItemsByCurrentType() => allShopItems.Where(x => x.type.Equals("Consumable", System.StringComparison.OrdinalIgnoreCase)).ToList();
    protected override EquipmentSlotUI.ShopPanelType GetShopPanelType() => EquipmentSlotUI.ShopPanelType.ShopPK;
}