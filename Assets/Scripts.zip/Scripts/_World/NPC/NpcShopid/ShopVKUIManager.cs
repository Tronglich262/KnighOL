﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class ShopVKUIManager : BaseShopUIManager
{
    protected override ShopType CurrentShopType => ShopType.Weapon;
    protected override List<NpcShopItem> FilterItemsByCurrentType() => allShopItems.Where(x => x.type.Equals("Weapon", System.StringComparison.OrdinalIgnoreCase)).ToList();
    protected override EquipmentSlotUI.ShopPanelType GetShopPanelType() => EquipmentSlotUI.ShopPanelType.ShopVK;
}