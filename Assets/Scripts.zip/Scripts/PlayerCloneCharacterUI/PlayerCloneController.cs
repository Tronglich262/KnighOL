﻿using Assets.HeroEditor.Common.CharacterScripts;
using Fusion;
using UnityEngine;

public class PlayerCloneController : MonoBehaviour
{
    public NetworkObject targetPlayerNetworkObject;
    private PlayerAvatar targetAvatar;

    public void SetTarget(NetworkObject playerObj)
    {
        targetPlayerNetworkObject = playerObj;
        targetAvatar = playerObj.GetComponent<PlayerAvatar>();
    }

    public void SendCharacterJsonToTarget(string json)
    {
        if (targetAvatar != null && targetAvatar.HasStateAuthority)
        {
            targetAvatar.UpdateCharacterJson(json); //  Chia JSON thành 7 phần
            targetAvatar.SendCharacterJsonToAllClients(); //  Fusion tự sync

            Debug.Log(" JSON đã gửi từ clone về player thật.");
        }
        else
        {
            Debug.LogWarning(" Không gửi được JSON vì targetAvatar null hoặc không có quyền.");
        }
    }


    public void LoadJson(string json)
    {
        if (string.IsNullOrEmpty(json))
        {
            Debug.LogWarning(" Không có dữ liệu JSON để load.");
            return;
        }

        if (TryGetComponent<Character>(out var character))
        {
            character.FromJson(json);

            character.Initialize();
            Debug.Log(" PlayerClone đã load character từ JSON.");
        }
        else
        {
            Debug.LogError(" Không tìm thấy component Character trong clone.");
        }
    }


}
