﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class ShopTPUIManager : BaseShopUIManager
{
    protected override ShopType CurrentShopType => ShopType.Accessory;
    protected override List<NpcShopItem> FilterItemsByCurrentType() => allShopItems.Where(x => x.type.Equals("Accessory", System.StringComparison.OrdinalIgnoreCase)).ToList();
    protected override EquipmentSlotUI.ShopPanelType GetShopPanelType() => EquipmentSlotUI.ShopPanelType.ShopTP;
}