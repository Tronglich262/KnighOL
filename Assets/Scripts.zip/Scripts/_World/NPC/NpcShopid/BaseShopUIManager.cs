// Assets/Scripts/_World/NPC/NpcShopid/BaseShopUIManager.cs
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public abstract class BaseShopUIManager : MonoBehaviour
{
    public static BaseShopUIManager Instance { get; private set; }

    [Header("Shop UI References")]
    public Transform contentParent;
    public GameObject shopItemPrefab;

    protected List<NpcShopItem> allShopItems = new List<NpcShopItem>();
    protected List<GameObject> currentUIs = new List<GameObject>();

    protected abstract ShopType CurrentShopType { get; }
    protected abstract EquipmentSlotUI.ShopPanelType GetShopPanelType();

    protected virtual void Awake()
    {
        Instance = this;
    }

    public virtual IEnumerator ShowShop(List<NpcShopItem> items)
    {
        allShopItems = items ?? new List<NpcShopItem>();
        var filtered = FilterItemsByCurrentType();
        yield return StartCoroutine(DisplayFilteredItems(filtered));
    }

    protected abstract List<NpcShopItem> FilterItemsByCurrentType();

    protected virtual IEnumerator DisplayFilteredItems(List<NpcShopItem> items)
    {
        ClearUI();
        foreach (var item in items)
        {
            CreateShopItemUI(item);
            yield return null;
        }
    }

    public void StartFilterShopByType(string type)
    {
        StopAllCoroutines();
        StartCoroutine(FilterShopByTypeCoroutine(type));
    }

    private IEnumerator FilterShopByTypeCoroutine(string type)
    {
        var filtered = allShopItems
            .Where(x => x.type.Equals(type, System.StringComparison.OrdinalIgnoreCase))
            .ToList();

        yield return StartCoroutine(DisplayFilteredItems(filtered));
    }

    // ====================== FIX CHÍNH – GIỐNG CODE CŨ ======================
    protected virtual void CreateShopItemUI(NpcShopItem item)
    {
        if (item == null) return;

        // === Cách cũ nhất mà shopvk/shoppk/ShopTP đang dùng ===
        ItemStats stats = ItemStatDatabase.Instance.GetStats(item.itemId.ToString());

        // Nếu GetStats(string) vẫn miss → thử GetStatsdtb(int)
        if (stats == null)
            stats = ItemStatDatabase.Instance.GetStatsdtb(item.itemId);

        if (stats == null)
        {
            Debug.LogWarning($"Không tìm thấy stats cho itemId: {item.itemId}");
            return;
        }

        GameObject obj = Instantiate(shopItemPrefab, contentParent);
        var slotUI = obj.GetComponent<EquipmentSlotUI>();

        slotUI.SetItem(stats.itemId, stats.Icon, item.type, item.price);
        slotUI.npcShopItemData = item;
        slotUI.shopPanelType = GetShopPanelType();

        currentUIs.Add(obj);
    }

    protected void ClearUI()
    {
        foreach (var ui in currentUIs)
            if (ui != null) Destroy(ui);
        currentUIs.Clear();
    }
}