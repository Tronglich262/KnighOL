﻿using Assets.HeroEditor.Common.CommonScripts;
using Assets.HeroEditor.Common.ExampleScripts;
using Unity.VisualScripting.Antlr3.Runtime.Misc;
using UnityEngine;
using UnityEngine.UI;
public class CharacterUIManager : MonoBehaviour
{
    public GameObject characterPanel;
    public GameObject Tui;
    public GameObject TiemNang;
    public GameObject Kynang;
    public GameObject Tiemnangbtn;
    public GameObject Kynangbtn;
    public GameObject Banthanbtn;
    public GameObject Nhiemvubtn;
    public GameObject Tuibtn;
    public GameObject Thongtinbtn;
    public GameObject Closebtn;
    public GameObject codecharacterui1;
    public GameObject characterpreviewpanel;
    public GameObject CharacterButton;
    public GameObject nhiemvu;
    public GameObject kynangCharacter;
    public static CharacterUIManager Instance;

    public Image Vien;
    void Awake()
    {
        if (Instance == null) Instance = this;
        else if (Instance != this) Destroy(gameObject);
    }
    private void Start()
    {
        characterPanel.SetActive(false);
        characterpreviewpanel.SetActive(false);
        TiemNang.SetActive(false);
        Kynang.SetActive(false);
        Tiemnangbtn.SetActive(false);
        Kynangbtn.SetActive(false);
        Banthanbtn.SetActive(false);
        Nhiemvubtn.SetActive(false);
        Tuibtn.SetActive(false);
        Thongtinbtn.SetActive(false);
        Closebtn.SetActive(false);
        Tui.SetActive(false);
        codecharacterui1.SetActive(false);
        Vien.SetActive(false);
        nhiemvu.SetActive(false);
        kynangCharacter.SetActive(false);
    }
 
    public void TogglePanel()
    {
        bool isActive = characterPanel.activeSelf;
        FpsGame.Instance.ToggleTatBanghienthithongtin();
        SkillButtonManager.Instance.ToggleSkills(false);

        if (isActive)
        {
            // Nếu đang mở, thì ẩn hết
            characterPanel.SetActive(false);
            Tui.SetActive(false);
            TiemNang.SetActive(false);
            Kynang.SetActive(false);
            Tiemnangbtn.SetActive(false);
            Kynangbtn.SetActive(false);
            Banthanbtn.SetActive(false);
            Nhiemvubtn.SetActive(false);
            Tuibtn.SetActive(false);
            Thongtinbtn.SetActive(false);
            Closebtn.SetActive(false);
            codecharacterui1.SetActive(false);
            Vien.SetActive(false);
          //  QuestDisplay.Instance.TatactiveallQuestDisplay();
            kynangCharacter.SetActive(false);

        }
        else
        {
            bool canShow =
                   (CharacterPreviewPanel.Instance == null || !CharacterPreviewPanel.Instance.gameObject.activeSelf) &&

         (!WorldChatUIManager.Instance.privateChatPanel.gameObject.activeSelf &&
          !WorldChatUIManager.Instance.chatPanel.gameObject.activeSelf &&
          !WorldChatUIManager.Instance.privateChatListPanel.gameObject.activeSelf &&
          !ShopTriggerTA.Instance.shopPanel.gameObject.activeSelf &&
          !ShopTriggerPK.Instance.shopPanel.gameObject.activeSelf &&
          !ShopTriggerVK.Instance.shopPanel.gameObject.activeSelf &&
          !ShopTriggerTP.Instance.shopPanel.gameObject.activeSelf &&
         // !CanvasShop.Instante.canvasShop.gameObject.activeSelf &&
          //!CanvasShop.Instante.canvasDaily.gameObject.activeSelf &&
          !CanvasShop.Instante.canvasShopPK.gameObject.activeSelf &&
          !CanvasShop.Instante.canvasShopvk.gameObject.activeSelf);

            if (canShow)
            {
                // Nếu tất cả panel chat & preview đều đang tắt thì bật lên
                characterPanel.SetActive(true);
                Tui.SetActive(true);
                TiemNang.SetActive(false);
                Kynang.SetActive(false);
                nhiemvu.SetActive(false);
                kynangCharacter.SetActive(false);
                Tiemnangbtn.SetActive(true);
                Kynangbtn.SetActive(true);
                Banthanbtn.SetActive(true);
                Nhiemvubtn.SetActive(true);
                Tuibtn.SetActive(true);
                Thongtinbtn.SetActive(true);
                Closebtn.SetActive(true);
                codecharacterui1.SetActive(true);
                Vien.SetActive(true);
                CharacterButton.SetActive(false); 
                WorldChatUIManager.Instance.ToggleTatCharbarAndChatPrivateList();
                QuestDisplay.Instance.TatactiveallQuestDisplay();               
              //  bool checktoggle = MovementExample.Instante.checktoggle = true;
              //  SkillButtonManager.Instance.Skillbutton.SetActive(false);

            }
        }
    }

    public void ToggleThongtin()
    {
        characterPanel.SetActive(true);
        TiemNang.SetActive(false);
        Kynang.SetActive(false);
        nhiemvu.SetActive(false);
        Tui.SetActive(true);
        Vien.SetActive(true);
        kynangCharacter.SetActive(false);


    }
    public void ToggleTiemNang()
    {
        TiemNang.SetActive(true);
        Kynang.SetActive(false);
        characterPanel.SetActive(true);
        Tui.SetActive(false);
        Vien.SetActive(true);
        nhiemvu.SetActive(false);
        kynangCharacter.SetActive(false);
        TiemNang.GetComponent<PotentialStatsPanel>().Show();


    }
    public void ToggleKyNang()
    {
        kynangCharacter.SetActive(true);
        TiemNang.SetActive(false);
        characterPanel.SetActive(true);
        Vien.SetActive(true);
        nhiemvu.SetActive(false);
    }
    public void TuiButton()
    {
        Tui.SetActive(true);
        Kynang.SetActive(false);
        TiemNang.SetActive(false);
        characterPanel.SetActive(true);
        Tiemnangbtn.SetActive(true);
        Kynangbtn.SetActive(true);
        Banthanbtn.SetActive(true);
        Nhiemvubtn.SetActive(true);
        Vien.SetActive(true);
        nhiemvu.SetActive(false);

    }
    public void nhiemvuButton()
    {
        nhiemvu.SetActive(true);
        Kynang.SetActive(false);
        TiemNang.SetActive(false);
        characterPanel.SetActive(true);
        Tiemnangbtn.SetActive(true);
        Kynangbtn.SetActive(true);
        Banthanbtn.SetActive(true);
        Nhiemvubtn.SetActive(true);
      
        Vien.SetActive(true);

    }
    public void TTButton()
    {
        characterPanel.SetActive(true);
        Kynang.SetActive(true);
        TiemNang.SetActive(false);
        Tui.SetActive(false);
        Tiemnangbtn.SetActive(true);
        Kynangbtn.SetActive(true);
        Banthanbtn.SetActive(true);
        Nhiemvubtn.SetActive(true);
      
        Vien.SetActive(true);
        nhiemvu.SetActive(false);
        if (ThongTin.instance != null && ThongTin.instance.gameObject.activeInHierarchy)
        {
            ThongTin.instance.StartCoroutine(
                AuthManager.Instance.GetPlayerStats(result =>
                {
                    ThongTin.instance.stats1 = result;
                    ThongTin.instance.UpdateStatsUI();
                })
            );
        }
    }
    //====phần thêm thông tin account khác======
    public void ShowPanelOnlyThongTin()
    {
        characterpreviewpanel.SetActive(true);   

    }
    public void ToggleTat()
    {
        
        characterpreviewpanel.SetActive(false);
        CharacterPreviewPanel.Instance.ClearPreviewData();
      //  SkillButtonManager.Instance.Skillbutton.SetActive(true);
        WorldChatUIManager.Instance.Chat.SetActive(true);
        QuestDisplay.Instance.BatactiveallQuestDisplay();
        WorldChatUIManager.Instance.chatBar.SetActive(true);
        CharacterUIManager.Instance.CharacterButton.SetActive(true);
        SettingPanel.Instance.Setting.SetActive(true);
    }
    public void ToggleTatall()
    {
        CharacterButton.SetActive(true); 
        characterPanel.SetActive(false);
        TiemNang.SetActive(false);
        Kynang.SetActive(false);
        Tiemnangbtn.SetActive(false);
        Kynangbtn.SetActive(false);
        Banthanbtn.SetActive(false);
        Nhiemvubtn.SetActive(false);
        Tuibtn.SetActive(false);
        Thongtinbtn.SetActive(false);
        Closebtn.SetActive(false);
        Tui.SetActive(false);
        codecharacterui1.SetActive(false);
        Vien.SetActive(false);
        kynangCharacter.SetActive(false);
        nhiemvu.SetActive(false);
        QuestDisplay.Instance.BatactiveallQuestDisplay();
        WorldChatUIManager.Instance.ToggleBatCharbarAndChatPrivateList();
        FpsGame.Instance.ToggleBatBanghienthithongtin();

        //  bool checktoggle = MovementExample.Instante.checktoggle = false;
        SkillButtonManager.Instance.ToggleSkills(true);

    }
    public void ToggleTatCharacterButton()
    {
        CharacterButton.SetActive(false);
    }
    public void ToggleBatCharacterButton()
    {
        CharacterButton.SetActive(true);
    }
}
