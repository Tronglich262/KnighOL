﻿using Assets.HeroEditor.Common.CharacterScripts;
using HeroEditor.Common;
using HeroEditor.Common.Enums;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;

public static class CharacterEquipHandler
{

    public static void EquipItemToCharacter(InventoryItem1 item)
    {
        if (item == null || item.stats == null)
        {
            return;
        }

        var character = CharacterUIManager1.Instance.character;
        var type = item.stats.Type;
        var itemId = item.itemId;

        var dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(PlayerDataHolder1.CharacterJson);

        switch (type)
        {
            case "Bow":
                dict["Bow"] = itemId;
                dict["WeaponType"] = "Bow";
                break;
            case "MeleeWeapon1H":
                dict["PrimaryMeleeWeapon"] = itemId;
                dict["WeaponType"] = "Melee1H";
                break;
            case "MeleeWeapon2H":
                dict["SecondaryMeleeWeapon"] = itemId;
                dict["WeaponType"] = "Melee2H";
                break;
            default:
                dict[type] = itemId;
                break;
        }

        // Nếu là Armor riêng lẻ → gán trực tiếp
        if (ArmorTypeToIndexes.ContainsKey(type))
        {
            var entry = character.SpriteCollection.Armor.Find(e => e.Id == itemId);
            if (entry != null)
            {
                var indexes = ArmorTypeToIndexes[type];

                if (entry.Sprites.Count < indexes.Count)
                {
                    return;
                }

                while (character.Armor.Count < 12) character.Armor.Add(null);

                for (int i = 0; i < indexes.Count; i++)
                {
                    character.Armor[indexes[i]] = entry.Sprites[i];
                }

                character.EquipArmor(character.Armor);
            }
        }

        else
        {
            // Với các loại khác → vẫn dùng FromJson
            string updatedJson = JsonConvert.SerializeObject(dict, Formatting.None);
            PlayerDataHolder1.CharacterJson = updatedJson;
            character.FromJson(updatedJson);
        }

        //  Sau khi gán Armor, ta đồng bộ lại JSON (rất quan trọng!)
        dict["Armor"] = SaveArmorState(character.Armor);
        string finalJson = JsonConvert.SerializeObject(dict, Formatting.None);
        PlayerDataHolder1.CharacterJson = finalJson;

        // Gửi server nếu có
        if (AuthManager.Instance != null)
            AuthManager.Instance.StartCoroutine(AuthManager.Instance.SaveCharacterToServer(finalJson));

        //  Nếu là clone → gửi JSON về player thật
        if (ItemDetailsUI.Instance != null && ItemDetailsUI.Instance.playerClone != null)
        {
            var cloneController = ItemDetailsUI.Instance.playerClone.GetComponent<PlayerCloneController>();
            if (cloneController != null)
            {
                cloneController.SendCharacterJsonToTarget(finalJson);
            }
        }
        else
        {
            //  Nếu đang là player thật → cập nhật trực tiếp
            PlayerAvatar.Instance?.UpdateCharacterJson(finalJson);
        }
    }

    private static string SaveArmorState(List<Sprite> armor)
    {
        // Nếu bạn chỉ dùng 1 bộ Armor (toàn bộ là cùng 1 SpriteGroupEntry)
        // thì lấy ID của sprite đầu tiên là đủ (ví dụ sprite name = "MyArmor_Chest_0")
        if (armor == null || armor.All(s => s == null)) return "";

        // Tìm sprite name có dạng: "MyArmor_Chest_0", lấy phần MyArmor
        var first = armor.FirstOrDefault(s => s != null);
        if (first == null) return "";

        var name = first.name; // Ví dụ: "MyArmor_Torso_1"
        var id = name.Split('_')[0]; // "MyArmor"
        return id;
    }

    // Bảng ánh xạ giáp từng phần
    //Armor
    public static readonly Dictionary<string, List<int>> ArmorTypeToIndexes = new()
        {
            { "Pauldrons", new List<int> { 0, 1 } },                    // ArmL, ArmR
			{ "Boots",     new List<int> { 9, 7 } },                    // Shin, Leg
			{ "Vest",      new List<int> { 11 } },                     // Torso
			{ "Belt",     new List<int> { 8 } },                      // Pelvis
			{ "Gloves",    new List<int> { 3, 4, 2, 5, 6, 10 } }       // ForearmL, ForearmR, Finger, HandL, HandR, SleeveR
		};
    public static void TestEquipArmor(Character character, string armorId)
    {
        if (character == null)
        {
            return;
        }

        if (character.SpriteCollection == null)
        {
            return;
        }

        var entry = character.SpriteCollection.Armor.Find(e => e.Id == armorId);

        if (entry == null)
        {
            return;
        }

        var sprites = entry.Sprites;

        if (sprites == null || sprites.Count != 12)
        {
            return;
        }

        while (character.Armor.Count < 12)
        {
            character.Armor.Add(null);
        }

        for (int i = 0; i < 12; i++)
        {
            character.Armor[i] = sprites[i];
        }

        character.EquipArmor(character.Armor);
        character.Initialize();

    }
    public static void EquipPartialArmor(Character character, string type, Sprite sprite)
    {
        if (!ArmorTypeToIndexes.TryGetValue(type, out var indexes))
        {
            return;
        }

        while (character.Armor.Count < 12)
        {
            character.Armor.Add(null);
        }

        foreach (var i in indexes)
        {
            character.Armor[i] = sprite;
        }

        character.EquipArmor(character.Armor);
        character.Initialize();

    }
    public static readonly Dictionary<string, List<int>> BowTypeToIndexes = new()
        {
            { "Arrow", new List<int> { 0 } },                  
			{ "Limb",     new List<int> { 1 } },                 
			{ "Riser",      new List<int> { 2 } },                 
		};
    public static void EquipPartialBow(Character character, string type, Sprite sprite)
    {
        if (!BowTypeToIndexes.TryGetValue(type, out var indexes))
        {
            return;
        }

        while (character.Bow.Count < 2)
        {
            character.Bow.Add(null);
        }

        foreach (var i in indexes)
        {
            character.Bow[i] = sprite;
        }

        character.EquipBow(character.Bow);
        character.Initialize();

    }
    public static void TestEquipBow(Character character, string bowId)
    {
        if (character == null)
        {
            return;
        }

        if (character.SpriteCollection == null)
        {
            return;
        }

        var entry = character.SpriteCollection.Bow.Find(e => e.Id == bowId);

        if (entry == null)
        {
            return;
        }

        var sprites = entry.Sprites;

        if (sprites == null || sprites.Count != 2)
        {
            return;
        }
        while (character.Bow.Count < 2)
        {
            character.Bow.Add(null);
        }
        for (int i = 0; i < 2; i++)
        {
            character.Bow[i] = sprites[i];
        }
        character.EquipBow(character.Bow);
        character.Initialize();
        Debug.Log($"✅ TestEquipBow: Gán Bow '{entry.Name}' thành công.");
    }

}
